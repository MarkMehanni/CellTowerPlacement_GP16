<html>
<head>
	<title></title >
	<link rel="stylesheet" type= "text/css" href="/CellTowerPlacement_GP16/WebPage/style1.css">
</head>
<body>
	<div class="navBar">
		<h1>
			<a href="home.php" class="Lemonade">CTP monitor <img class="lemon" src="celltower2.svg"></a>
		</h1>
		<ul>
			<li><a href="logg.php" class="login">Login</a></li>
			<li><a href="signUpIndex.php" class="signup">Sign up</a></li>
		</ul>
	</div>
	
	<div class="wrapper1">
		<h1 class="welcomeText">
			Cell Tower <br/>
			Placement (CTP) <br/>
			Monitor 
		</h1>
		<h1 class="sectionText1">
			CTP is an applicaton that <br>monitors and suggests the finest <br>place to deploy a cell tower
		</h1>
		<img class="illustration" src="celltower2.svg">
		
	</div>
	
	
</body>
</html>
