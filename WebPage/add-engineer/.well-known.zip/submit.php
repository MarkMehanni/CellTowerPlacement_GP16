<head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
<?php
$link = mysqli_connect("","campqvyh_campqvyh","Iq4S9NmCk5gC") or die("failed to connect to server !!");
mysqli_select_db($link,"campqvyh_attendance_data");

if(isset($_POST['submit']))
{
	$errorMessage = "";
    $fname = $_POST['fname'];
	$mname = $_POST['mname'];
	$lname = $_POST['lname'];
	$uni_id = $_POST['uni_id'];
	$faculty = $_POST['faculty'];
	$department = $_POST['department'];
	
 	
	
if ($errorMessage != "" ) 
{
	echo "<p class='message'>" .$errorMessage. "</p>" ;
}
else
{
	$sql="INSERT INTO campqvyh_attendance_data.data(fname,mname, lname, uni_id, faculty,department ) VALUES ('$fname','$mname' ,'$lname', '$uni_id',  '$faculty','$department' )";
	mysqli_query($link,$sql) or die(mysqli_error($link));
}
}
?>
<div class="container">
  
  <div class="alert alert-success">
    <strong>Item added successfully!</strong>
  </div></body>